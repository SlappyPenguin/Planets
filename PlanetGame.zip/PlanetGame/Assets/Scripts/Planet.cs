using System;
using UnityEngine;

public class Planet : MonoBehaviour {
    public int maxHealth = 1;
    public int health = 1;
    public float maxSpeed = 20f;

    void Start() {
        health = maxHealth;
    }

    void Update() {
        if (health <= 0) Destroy(gameObject);
        float speed = gameObject.GetComponent<Rigidbody2D>().velocity.magnitude;
        if (speed <= maxSpeed) return;
        gameObject.GetComponent<Rigidbody2D>().velocity *= maxSpeed / speed;
    }

    private void OnCollisionEnter2D(Collision2D otherCollider) {
        Planet other = otherCollider.gameObject.GetComponent<Planet>();
        if(other == null) return;
        health = 0;
        other.health = 0;
    }
}
