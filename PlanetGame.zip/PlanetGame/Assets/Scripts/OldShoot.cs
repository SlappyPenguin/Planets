using NUnit.Framework;
using Unity.VisualScripting;
using UnityEngine;

public class OldShoot : MonoBehaviour {
    public GameObject bulletPrefab;
    public int numBullets = 10;
    public float sprayAngle = 10f;
    private OldProjectile proj;
    private float timeSinceLastShot = 9999f;

    void Start() {
        timeSinceLastShot = proj.reloadTime;
    }

    void Update() {
        proj = bulletPrefab.GetComponent<OldProjectile>();

        timeSinceLastShot += Time.deltaTime;
        if (!Input.GetMouseButtonDown(0)) return;
        if (timeSinceLastShot < proj.reloadTime) return;
        
        ShootBullet();
    }

    void ShootBullet() {
        Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector2 dir = (mousePos - (Vector2)transform.position).normalized;

        for (int i = 0; i < numBullets; i++) {
            float angle = (i - (numBullets - 1) / 2f) * sprayAngle;
            Vector2 sprayDir = Quaternion.Euler(0, 0, angle) * dir;

            GameObject bullet = Instantiate(bulletPrefab, transform.position + (Vector3) sprayDir, Quaternion.identity);
            OldProjectile iproj = bullet.GetComponent<OldProjectile>();

            bullet.GetComponent<Rigidbody2D>().velocity = sprayDir * iproj.speed + GetComponent<Rigidbody2D>().velocity;

            float projMass = iproj.mass;
            GetComponent<Rigidbody2D>().AddForce(-sprayDir * projMass * iproj.speed * 0.2f, ForceMode2D.Impulse);
        }

        timeSinceLastShot = 0f;
    }
}
