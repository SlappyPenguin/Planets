using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerShoot : MonoBehaviour {
    public GameObject projPrefab;
    public int numBullets = 1;
    public float sprayAngle = 10;
    public float slowDownFactor = 0.5f;
    public GameObject dragLine;

    private float timeSinceShot;
    private float reloadTime;
    
    void Start() {
        timeSinceShot = 99999999f;
    }

    void Update() {
        PlayerBullet playerBullet = projPrefab.GetComponent<PlayerBullet>();
        PlayerDrag playerDrag = projPrefab.GetComponent<PlayerDrag>();

        bool isDrag = false;
        if (playerBullet != null) reloadTime = playerBullet.reloadTime;
        if (playerDrag != null) {
            reloadTime = playerDrag.reloadTime;
            isDrag = true;
        } 

        timeSinceShot += Time.deltaTime;

        if (timeSinceShot < reloadTime && isDrag) dragLine.SetActive(false);
        if (timeSinceShot < reloadTime) return;
        if (isDrag) dragLine.SetActive(true);

        bool hasShot = false;
        if (playerBullet != null) hasShot = playerBullet.Shoot(numBullets, sprayAngle);
        else if (playerDrag != null) hasShot = playerDrag.Shoot(numBullets, sprayAngle, slowDownFactor);
        
        if (hasShot) timeSinceShot = 0;
    }
}
