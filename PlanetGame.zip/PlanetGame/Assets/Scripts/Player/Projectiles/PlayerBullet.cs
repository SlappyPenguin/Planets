using NUnit.Framework;
using UnityEngine;

public class PlayerBullet : MonoBehaviour {
    public float speed = 0f;
    public float activeTime = 0f;
    public float reloadTime = 0f;
    public int damage = 0;
    
    private float timeAlive = 0f;

    void Update() {
        timeAlive += Time.deltaTime;
        if (timeAlive > activeTime) Destroy(gameObject);
    }

    void OnCollisionEnter2D(Collision2D other) {
        Planet planet = other.gameObject.GetComponent<Planet>();
        if (planet == null) {
            if (other.gameObject.tag == "Border") Destroy(gameObject);
            // If another bullet, do nothing
        } else if (other.gameObject.tag != "Player") {
            planet.health -= damage;
            Destroy(gameObject);
        }
    }

    public bool Shoot(int numBullets, float sprayAngle) {
        if (!Input.GetMouseButtonDown(0)) return false;

        Assert.AreEqual(numBullets % 2, 1); // For playablility's sake

        Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player == null) return false;
        Vector2 direction = (mousePos - (Vector2) player.transform.position).normalized;

        for (int i = 1; i <= numBullets; i++) {
            float angle = ((i - 1) - (numBullets - 1) / 2f) * sprayAngle;
            Vector2 sprayDir = Quaternion.Euler(0, 0, angle) * direction;

            GameObject bullet = Instantiate(gameObject, player.transform.position + (Vector3) sprayDir, Quaternion.identity);
            PlayerBullet playerBullet = bullet.GetComponent<PlayerBullet>();

            bullet.GetComponent<Rigidbody2D>().velocity = sprayDir * playerBullet.speed + player.GetComponent<Rigidbody2D>().velocity;
        }

        return true;
    }
}
