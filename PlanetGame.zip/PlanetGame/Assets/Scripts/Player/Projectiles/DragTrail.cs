using UnityEngine;

public class DragTrail : MonoBehaviour
{
    private LineRenderer lineRenderer;

    void Start() {
        lineRenderer = GetComponent<LineRenderer>();
    }

    public void RenderLine(Vector2 startPos, Vector2 endPos) {
        lineRenderer.positionCount = 2;
        lineRenderer.SetPosition(0, startPos);
        lineRenderer.SetPosition(1, endPos);
    }

    public void EndLine() {
        lineRenderer.positionCount = 0;
    }

    private Vector2 startPos;
    private Vector2 endPos;
    void Update() {
        if (Input.GetMouseButtonDown(0)) {
            startPos = Input.mousePosition;
        } else if (Input.GetMouseButton(0)) {
            endPos = Input.mousePosition;
            RenderLine(Camera.main.ScreenToWorldPoint(startPos), Camera.main.ScreenToWorldPoint(endPos));
        } else if (Input.GetMouseButtonUp(0)) {
            EndLine();
        }
    }
}
