using UnityEngine;
using NUnit.Framework;

public class PlayerDrag : MonoBehaviour {
    public float baseSpeed = 0f;
    public float activeTime = 0f;
    public float reloadTime = 0f;
    public int damage = 0;
    public float multiplier = 1f;
    
    private float timeAlive = 0f;

    void Update() {
        timeAlive += Time.deltaTime;
        if (timeAlive > activeTime) Destroy(gameObject);
    }

    void OnCollisionEnter2D(Collision2D other) {
        Planet planet = other.gameObject.GetComponent<Planet>();
        if (planet == null) {
            if (other.gameObject.tag == "Border") Destroy(gameObject);
            // If another bullet, do nothing
        } else if (other.gameObject.tag != "Player") {
            planet.health -= damage;
            Destroy(gameObject);
        }
    }

    Vector2 startPos;
    Vector2 endPos;

    public bool Shoot(int numBullets, float sprayAngle, float slowDownFactor) {
        if (!Input.GetMouseButtonDown(0) && !Input.GetMouseButtonUp(0)) return false;

        if (Input.GetMouseButtonDown(0)) {
            startPos = Input.mousePosition;
            Time.timeScale = slowDownFactor;
        }
        
        if (Input.GetMouseButtonUp(0)) {
            Time.timeScale = 1f;
            Assert.AreEqual(numBullets % 2, 1); // For playablility's sake

            endPos = Input.mousePosition;
            Vector2 startPosWorld = Camera.main.ScreenToWorldPoint(startPos);
            Vector2 endPosWorld = Camera.main.ScreenToWorldPoint(endPos);

            Vector2 direction = (startPosWorld - endPosWorld).normalized;

            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player == null) return false;

            for (int i = 1; i <= numBullets; i++) {
                float angle = ((i - 1) - (numBullets - 1) / 2f) * sprayAngle;
                Vector2 sprayDir = Quaternion.Euler(0, 0, angle) * direction;

                GameObject bullet = Instantiate(gameObject, player.transform.position + (Vector3) sprayDir, Quaternion.identity);
                PlayerDrag playerBullet = bullet.GetComponent<PlayerDrag>();

                bullet.GetComponent<Rigidbody2D>().velocity = sprayDir * (playerBullet.baseSpeed + (startPosWorld - endPosWorld).magnitude * multiplier) + player.GetComponent<Rigidbody2D>().velocity;
            }

            return true;
        }

        return false;
    }
}
