using System;
using UnityEngine;

public class MassChange : MonoBehaviour {
    public float scale = 2.5f;
    public float maxStamina = 5f;
    public float minCooldown = 1f;
    public float stamina = 0f;
    private float cooldown = 0f;
    private bool isChanged = false;

    void Start() {
        stamina = maxStamina;
    }

    void Update() {
        if (!isChanged) {
            stamina = Math.Min(stamina + Time.deltaTime, maxStamina);
            cooldown = Math.Min(cooldown + Time.deltaTime, minCooldown);
        } else stamina = Math.Max(stamina - Time.deltaTime, 0f);

        Rigidbody2D rigidBody = GetComponent<Rigidbody2D>();
        if (!isChanged && Input.GetKeyDown(KeyCode.LeftShift) && cooldown == minCooldown) {
            isChanged = true;
            rigidBody.velocity *= scale;
            rigidBody.mass /= scale;
            cooldown = 0f;
        } else if (isChanged && (Input.GetKeyUp(KeyCode.LeftShift) || stamina == 0f)) {
            isChanged = false;
            rigidBody.velocity /= scale;
            rigidBody.mass *= scale;
            cooldown = 0f;
        }
    }
}
