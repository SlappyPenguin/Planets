using UnityEngine;

public class EnemyShoot : MonoBehaviour {
    public GameObject bulletPrefab;
    public float deviation = 0.1f;
    
    private OldProjectile proj;
    private float timeSinceLastShot = 9999f;

    void Start() {
        proj = bulletPrefab.GetComponent<OldProjectile>();
        timeSinceLastShot = proj.reloadTime;
    }

    void Update() {
        timeSinceLastShot += Time.deltaTime;
        if (timeSinceLastShot < proj.reloadTime) return;
        ShootBullet();
    }

    void ShootBullet() {
        if (GameObject.FindGameObjectWithTag("Player") == null) return;
        GameObject player = GameObject.FindGameObjectWithTag("Player");

        Vector2 dir = (Vector2) player.transform.position - (Vector2) transform.position;
        Vector2 playerVelocity = player.GetComponent<Rigidbody2D>().velocity;
        dir += playerVelocity * (dir.magnitude / proj.speed);
        dir = Quaternion.Euler(0, 0, Random.Range(-deviation, deviation)) * dir.normalized;

        GameObject bullet = Instantiate(bulletPrefab, transform.position + (Vector3) dir, Quaternion.identity);
        OldProjectile iproj = bullet.GetComponent<OldProjectile>();

        bullet.GetComponent<Rigidbody2D>().velocity = dir * iproj.speed + GetComponent<Rigidbody2D>().velocity;
        timeSinceLastShot = 0f;
    }
}
