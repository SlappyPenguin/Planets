using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class HealthFiller : MonoBehaviour {
    private GameObject player;
    private Slider slider;
    public TMP_Text text;

    void Start() {
        player = GameObject.FindGameObjectWithTag("Player");
        slider = gameObject.GetComponent<Slider>();   
    }

    void Update() {
        int health = 0, maxHealth = 0;
        if (player != null) {
            health = player.GetComponent<Planet>().health;
            maxHealth = player.GetComponent<Planet>().maxHealth;
        } 

        slider.value = health;
        slider.maxValue = maxHealth;
        text.text = health.ToString() + "/" + maxHealth.ToString();
    }
}
