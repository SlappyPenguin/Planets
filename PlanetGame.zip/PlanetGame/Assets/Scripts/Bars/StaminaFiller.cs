using NUnit.Framework;
using UnityEngine;
using UnityEngine.UI;

public class StaminaFiller : MonoBehaviour {
    private GameObject player;
    private Slider slider;

    void Start() {
        player = GameObject.FindGameObjectWithTag("Player");
        slider = gameObject.GetComponent<Slider>();
    }

    void Update() {
        float stamina = 0, maxStamina = 0;
        if (player != null) {
            stamina = player.GetComponent<MassChange>().stamina;
            maxStamina = player.GetComponent<MassChange>().maxStamina;
        } 

        slider.value = stamina;
        slider.maxValue = maxStamina;
    }
}
