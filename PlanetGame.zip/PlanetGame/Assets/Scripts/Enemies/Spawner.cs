using System.Collections;
using UnityEngine;

public class Spawner : MonoBehaviour {
    private float errorMargin = 1f;
    public float minSpawnDistance = 3f;

    public float minEnemySpeed = 2f;
    public float maxEnemySpeed = 4f;
    
    public GameObject[] enemyPrefabs;
    public float[] spawnChances;

    private GameObject[] borders;
    private Camera mainCamera;

    public int[] numEnemiesPerSpawn = {5};
    public int[] numSpawnsPerWave = {5};
    public float[] delayBetweenSpawns = {2f};

    public int[] numWaves = {1};
    public float[] delayBetweenWaves = {5f};
    
    void Start() {
        mainCamera = Camera.main;
        borders = GameObject.FindGameObjectsWithTag("Border");


        Debug.Log("Level 1");
        StartCoroutine(PlayLevel(0));
    }

    void Update() {
        
    }

    bool IsInCamera(Vector2 pos) {
        float height = 2f * mainCamera.orthographicSize + 2 * errorMargin;
        float width = height * mainCamera.aspect + 2 * errorMargin;
        if (Mathf.Abs(pos.x - mainCamera.transform.position.x) > width / 2) return false;
        if (Mathf.Abs(pos.y - mainCamera.transform.position.y) > height / 2) return false;
        return true;
    }

    IEnumerator PlayLevel(int levelID) {
        for(int i = 0; i < numWaves[levelID]; i++) {
            Debug.Log("Wave " + (i+1));
            StartCoroutine(CreateWave(numEnemiesPerSpawn[levelID], numSpawnsPerWave[levelID], delayBetweenSpawns[levelID]));
            yield return new WaitForSeconds(delayBetweenWaves[levelID] + numSpawnsPerWave[levelID] * delayBetweenSpawns[levelID]);
        }
    }

    IEnumerator CreateWave(int numPerSpawn, int rep, float delay) {
        for(int i = 0; i < rep; i++) {
            Debug.Log("Spawn " + (i+1));
            Spawn(numPerSpawn);
            yield return new WaitForSeconds(delay);
        }
    }

    void Spawn(int numEnemies) {
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");

        float maxY = -9999f, maxX = -9999f, minY = 9999f, minX = 9999f;
        foreach (GameObject border in borders) {
            maxY = Mathf.Max(maxY, border.transform.position.y);
            maxX = Mathf.Max(maxX, border.transform.position.x);
            minY = Mathf.Min(minY, border.transform.position.y);
            minX = Mathf.Min(minX, border.transform.position.x);
        }
        
        int attempts = 0;
        for (int i = 1; i <= numEnemies; i++) {
            if (attempts > 100) break;

            float x = Random.Range(minX, maxX);
            float y = Random.Range(minY, maxY);
            if (IsInCamera(new Vector2(x, y))) {
                i--; attempts++;
                continue;
            }
            bool halt = false;
            foreach (GameObject enemy in enemies) {
                if (Vector2.Distance(enemy.transform.position, new Vector2(x, y)) < minSpawnDistance) {
                    halt = true;
                    break;
                }
            }
            if (halt) {
                i--; attempts++;
                continue;
            }
            attempts = 0;

            float rand = Random.Range(0f, 1f);
            float sum = 0f;
            GameObject enemyPrefab = null;
            for (int j = 0; j < spawnChances.Length; j++) {
                sum += spawnChances[j];
                if (rand <= sum) {
                    enemyPrefab = enemyPrefabs[j];
                    break;
                }
            }
            if (enemyPrefab == null) {
                Debug.LogError("Error: enemyPrefab is null");
                return;
            }
            GameObject newEnemy = Instantiate(enemyPrefab, new Vector3(x, y, 0), Quaternion.identity);
            
            Vector2 newVelocity = mainCamera.transform.position - newEnemy.transform.position;

            Vector2 playerVelocity = Vector2.zero;
            // if(GameObject.Find("Player") != null) playerVelocity = GameObject.Find("Player").GetComponent<Rigidbody2D>().velocity;
            // else playerVelocity = Vector2.zero;

            newEnemy.GetComponent<AddInitial>().velocity = newVelocity.normalized * Random.Range(minEnemySpeed, maxEnemySpeed) + playerVelocity;
            enemies = GameObject.FindGameObjectsWithTag("Enemy"); // slow but works
        }
    }
}
