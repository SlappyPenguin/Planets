using System.Collections.Generic;
using UnityEngine;

public class EnemyIndicator : MonoBehaviour {

    private Camera mainCamera;
    public float errorMargin = 1f;
    public GameObject indicatorPrefab;

    private List<GameObject> indicators = new List<GameObject>();

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start() {
        mainCamera = Camera.main;
    }

    // Update is called once per frame
    void Update() {
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");

        foreach(GameObject indicator in indicators) Destroy(indicator);
        indicators.Clear();
        
        for(int i = 0; i < enemies.Length; i++) {
            if(IsInCamera(enemies[i].transform.position)) continue;

            // find intersection point between line from camera to enemy and border
            Vector2 enemyScreenPos = mainCamera.WorldToScreenPoint(enemies[i].transform.position);
            Vector2 cameraScreenPos = mainCamera.WorldToScreenPoint(mainCamera.transform.position);
            Vector2 direction = enemyScreenPos - cameraScreenPos;
            Vector2 intersection = Vector2.zero;
            if(direction.x == 0) {
                intersection.x = enemyScreenPos.x;
                intersection.y = direction.y > 0 ? Screen.height : 0;
            } else if(direction.y == 0) {
                intersection.y = enemyScreenPos.y;
                intersection.x = direction.x > 0 ? Screen.width : 0;
            } else {
                float slope = direction.y / direction.x;
                // find intercepts with x = 0, x = Screen.width, y = 0, y = Screen.height
                float leftIntercept = enemyScreenPos.y - slope * enemyScreenPos.x;
                float rightIntercept = enemyScreenPos.y - slope * (enemyScreenPos.x - Screen.width);
                float topIntercept = enemyScreenPos.x - (enemyScreenPos.y - Screen.height) / slope;
                float bottomIntercept = enemyScreenPos.x - enemyScreenPos.y / slope;

                // only one of these falls within the rectangle formed by the center of the screen and the enemy
                if(leftIntercept >= Mathf.Min(cameraScreenPos.y, enemyScreenPos.y) && leftIntercept <= Mathf.Max(cameraScreenPos.y, enemyScreenPos.y) && leftIntercept >= 0 && leftIntercept <= Screen.height) {
                    intersection.x = 0;
                    intersection.y = leftIntercept;
                } else if(rightIntercept >= Mathf.Min(cameraScreenPos.y, enemyScreenPos.y) && rightIntercept <= Mathf.Max(cameraScreenPos.y, enemyScreenPos.y) && rightIntercept >= 0 && rightIntercept <= Screen.height) {
                    intersection.x = Screen.width;
                    intersection.y = rightIntercept;
                } else if(topIntercept >= Mathf.Min(cameraScreenPos.x, enemyScreenPos.x) && topIntercept <= Mathf.Max(cameraScreenPos.x, enemyScreenPos.x) && topIntercept >= 0 && topIntercept <= Screen.width) {
                    intersection.x = topIntercept;
                    intersection.y = Screen.height;
                } else if(bottomIntercept >= Mathf.Min(cameraScreenPos.x, enemyScreenPos.x) && bottomIntercept <= Mathf.Max(cameraScreenPos.x, enemyScreenPos.x) && bottomIntercept >= 0 && bottomIntercept <= Screen.width) {
                    intersection.x = bottomIntercept;
                    intersection.y = 0;
                }
            }

            Vector2 anchoredPos;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(GetComponent<RectTransform>(), intersection, mainCamera, out anchoredPos);

            //place indicator at intersection point
            GameObject indicator = Instantiate(indicatorPrefab, transform, false);
            RectTransform indicatorTransform = indicator.GetComponent<RectTransform>();
            indicatorTransform.anchoredPosition = anchoredPos;
            // rotate indicator to face enemy
            indicatorTransform.rotation = Quaternion.Euler(0, 0, Vector2.SignedAngle(Vector2.up, enemyScreenPos - intersection));
            indicators.Add(indicator);
        }
    }

    bool IsInCamera(Vector2 pos) {
        float height = 2f * mainCamera.orthographicSize + 2 * errorMargin;
        float width = height * mainCamera.aspect + 2 * errorMargin;
        if (Mathf.Abs(pos.x - mainCamera.transform.position.x) > width / 2) return false;
        if (Mathf.Abs(pos.y - mainCamera.transform.position.y) > height / 2) return false;
        return true;
    }
}
