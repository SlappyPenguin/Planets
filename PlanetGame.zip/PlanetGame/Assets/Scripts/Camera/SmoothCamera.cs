using UnityEngine;

public class SmoothCamera : MonoBehaviour {
    public float speed = 3f;
    private Transform target;
    private Vector2 velocity = Vector2.zero;

    void Update() {
        if (GameObject.Find("Player") == null) return;
        target = GameObject.Find("Player").transform;
        Vector2 pos = Vector2.SmoothDamp(transform.position, target.position, ref velocity, 1/speed);
        transform.position = new Vector3(pos.x, pos.y, transform.position.z);
    }
}
