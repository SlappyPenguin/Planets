using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

public class OldProjectile : MonoBehaviour {
    public float speed = 0f;
    public float activeTime = 0f;
    public float reloadTime = 0f;
    public float mass = 1f;
    public int damage = 0;
    public bool fromPlayer = false;

    private float timeAlive = 0f;

    void Update() {
        timeAlive += Time.deltaTime;
        if (timeAlive >= activeTime) {
            Destroy(gameObject);
        }
    }

    void OnCollisionEnter2D(Collision2D other) {
        Planet pl = other.gameObject.GetComponent<Planet>();
        if (pl == null) {
            if(other.gameObject.tag == "Border") Destroy(gameObject);
            // do nothing
        } else if ((fromPlayer && other.gameObject.tag != "Player") || !fromPlayer) {
            pl.health -= damage;
            Destroy(gameObject);
        }
    }
}
