using UnityEngine;

public class AddInitial : MonoBehaviour {
    private Rigidbody2D body;
    public Vector2 velocity;

    void Start() {
        body = gameObject.GetComponent<Rigidbody2D>();
        body.velocity = velocity;
    }

    void OnDrawGizmos() {
        Gizmos.color = Color.red;
        Gizmos.DrawLine(transform.position, transform.position + (Vector3) velocity);
    }
}
